# Python-basic-projects
Some beginner level python projects using TKinter and some other libraries.
